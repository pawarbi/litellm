from .handler import AzureAIEmbedding
